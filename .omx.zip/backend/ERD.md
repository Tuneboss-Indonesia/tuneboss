# TuneBoss Inventory ERD

ERD ini mengikuti data yang benar-benar dipakai halaman frontend saat ini. Tabel/kolom legacy yang tidak dipakai FE sudah dikeluarkan: `suppliers`, `customers`, `restock_orders`, `sales.customer_id`, `sales.total_amount`, `sale_items.price`, `sale_items.subtotal`, `stock_movements.supplier_id`, dan `stock_movements.customer_id`.

Versi PlantUML tersedia di `ERD.puml`.

```mermaid
erDiagram
  users {
    uuid id PK
    string name
    string email
    string password
    string role
    boolean is_active
    timestamp created_at
    timestamp updated_at
  }

  personal_access_tokens {
    bigint id PK
    string tokenable_type
    uuid tokenable_id
    string name
    string token
    text abilities
    timestamp last_used_at
    timestamp expires_at
  }

  categories {
    uuid id PK
    string name
    text description
    timestamp created_at
    timestamp updated_at
  }

  products {
    uuid id PK
    uuid category_id FK
    string name
    string sku
    string barcode
    string image_path
    integer min_stock
    boolean is_active
    timestamp created_at
    timestamp updated_at
  }

  product_stocks {
    uuid id PK
    uuid product_id FK
    integer quantity
    timestamp created_at
    timestamp updated_at
  }

  sales {
    uuid id PK
    string invoice_number
    uuid cashier_id FK
    text address
    string status
    uuid voided_by FK
    timestamp voided_at
    text void_reason
    timestamp created_at
    timestamp updated_at
  }

  sale_items {
    uuid id PK
    uuid sale_id FK
    uuid product_id FK
    integer quantity
    timestamp created_at
    timestamp updated_at
  }

  stock_movements {
    uuid id PK
    uuid product_id FK
    uuid operator_id FK
    uuid sale_id FK
    string type
    integer quantity
    integer before_quantity
    integer after_quantity
    string party
    text note
    timestamp created_at
    timestamp updated_at
  }

  restock_alerts {
    uuid id PK
    uuid product_id FK
    string status
    string severity
    integer current_stock
    integer threshold
    uuid acknowledged_by FK
    timestamp acknowledged_at
    uuid resolved_by FK
    timestamp resolved_at
    text note
    timestamp created_at
    timestamp updated_at
  }

  audit_logs {
    uuid id PK
    uuid user_id FK
    string action
    string entity
    string entity_id
    json metadata
    string ip_address
    string user_agent
    timestamp created_at
  }

  users ||--o{ personal_access_tokens : owns
  users ||--o{ sales : cashiers
  users ||--o{ sales : voids
  users ||--o{ stock_movements : operates
  users ||--o{ restock_alerts : acknowledges
  users ||--o{ restock_alerts : resolves
  users ||--o{ audit_logs : writes
  categories ||--o{ products : groups
  products ||--|| product_stocks : has
  products ||--o{ sale_items : sold_as
  products ||--o{ stock_movements : moves
  products ||--o{ restock_alerts : alerts
  sales ||--o{ sale_items : contains
  sales ||--o{ stock_movements : creates
```

## Catatan Pemakaian FE

- `restock_alerts` tetap dipakai karena Dashboard menampilkan daftar produk habis dari endpoint `/restock-alerts`.
- `cashier_id`, `operator_id`, dan relasi user tetap dipakai backend untuk mencatat siapa yang melakukan transaksi/pergerakan, walaupun tidak semua kolomnya ditampilkan di tabel FE.
- Supplier dan customer sekarang hanya berupa teks bebas di `stock_movements.party` atau `sales.address`, bukan master table.
