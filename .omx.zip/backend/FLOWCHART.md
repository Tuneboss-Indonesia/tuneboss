# TuneBoss Inventory Flowchart

Flowchart ini mengikuti halaman frontend aktif: Dashboard, Kategori, Data Produk, Penjualan, Scan Barcode, Produk Masuk, Produk Keluar, Laporan, dan Admin.

Versi PlantUML tersedia di `FLOWCHART.puml`.

```mermaid
flowchart TD
  Start["User membuka aplikasi"] --> Login["Login"]
  Login --> Me["GET /auth/me"]
  Me --> Role{"Role admin?"}
  Role -->|"Ya"| AdminMenu["Menu Admin aktif"]
  Role -->|"Tidak"| StaffMenu["Menu Admin disembunyikan"]

  AdminMenu --> Pages["Halaman inventory"]
  StaffMenu --> Pages

  Pages --> Dashboard["Dashboard"]
  Dashboard --> DashSummary["GET /dashboard/summary"]
  Dashboard --> Alerts["GET /restock-alerts?severity=empty"]
  Dashboard --> Charts["GET /dashboard/sales-chart dan /top-products"]

  Pages --> Categories["Kategori"]
  Categories --> CatApi["GET/POST/PATCH/DELETE /categories"]

  Pages --> Products["Data Produk"]
  Products --> ProductApi["GET/POST/PATCH/DELETE /products"]
  Products --> ImageApi["POST/DELETE /products/{id}/image"]

  Pages --> Sales["Penjualan"]
  Sales --> SalesList["GET /sales"]
  Sales --> SalesWrite["POST/PATCH/DELETE /sales"]
  SalesWrite --> SaleItems["sale_items hanya product_id + quantity"]
  SalesWrite --> StockMinus["stok produk berkurang"]

  Pages --> Scan["Scan Barcode"]
  Scan --> Lookup["GET /products/lookup?barcode="]
  Lookup --> Found{"Produk ditemukan?"}
  Found -->|"Tidak"| NotFound["Tampilkan error"]
  Found -->|"Ya"| ChooseMove["Pilih Produk Masuk / Produk Keluar"]
  ChooseMove -->|"Masuk"| Inbound["POST /stock/inbound"]
  ChooseMove -->|"Keluar"| Outbound["POST /stock/outbound"]
  ChooseMove -->|"Keluar + checklist penjualan"| OutboundSale["POST /stock/outbound lalu POST /sales stock_already_moved=true"]
  Inbound --> Movement["stock_movements"]
  Outbound --> Movement
  OutboundSale --> Movement
  OutboundSale --> SalesList

  Pages --> InboundPage["Produk Masuk"]
  InboundPage --> InboundList["GET /stock/movements?type=inbound"]
  Pages --> OutboundPage["Produk Keluar"]
  OutboundPage --> OutboundList["GET /stock/movements?type=outbound"]

  Pages --> Reports["Data Laporan"]
  Reports --> ReportStock["GET /products"]
  Reports --> ReportSales["GET /sales"]
  Reports --> ReportInbound["GET /stock/movements?type=inbound"]
  Reports --> ReportOutbound["GET /stock/movements?type=outbound"]

  Pages --> Admin["Admin"]
  Admin --> Users["GET/POST/PATCH/DELETE /users"]
  Admin --> Logs["GET /audit-logs"]

  ProductApi --> Audit["audit_logs"]
  SalesWrite --> Audit
  Inbound --> Audit
  Outbound --> Audit
  Users --> Audit
```

## Yang Tidak Lagi Masuk Flow

- Master supplier/customer tidak ada di FE; form memakai input teks biasa.
- Restock order tidak ada halaman/menu aktif; yang aktif hanya `restock_alerts` untuk daftar produk habis di Dashboard.
- Harga, subtotal, dan total rupiah tidak dipakai alur FE; laporan memakai kuantitas.
